<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.header', [
        'title' => __('Edit Proverb: ') . $proverb->title,
        'meaning' => $proverb->meaning,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                
            </div>
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('proverbs.update', $proverb)); ?>" autocomplete="off" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            
                            <div class="card-header border-0">
                                <div class="row align-items-center">
                                     <div class="col-8"> </div>
                                    <div class="col-4 text-right">
                                        <a href="<?php echo e(route('proverbs.index')); ?>" class="btn btn-sm btn-primary">Back to Proverbs</a>
                                    </div>
                                </div>
                            </div>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <div class="pl-lg-4">                                
                                <div class="form-group<?php echo e($errors->has('title') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-title"><?php echo e(__('Proverb Name')); ?></label>
                                    <input type="text" name="title" id="input-title" class="form-control form-control-alternative<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" value="<?php echo e($proverb->title); ?>">

                                    <?php if($errors->has('title')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-group<?php echo e($errors->has('meaning') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-meaning"><?php echo e(__('Proverb Meaning (Optional)')); ?></label>
                                    <input type="text" name="meaning" id="input-meaning" class="form-control form-control-alternative<?php echo e($errors->has('meaning') ? ' is-invalid' : ''); ?>" value="<?php echo e($proverb->meaning); ?>">

                                    <?php if($errors->has('meaning')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('meaning')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-group<?php echo e($errors->has('synonyms') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-synonyms"><?php echo e(__('Proverb Synonyms (Optional)')); ?></label>
                                    <input type="text" name="synonyms" id="input-synonyms" class="form-control form-control-alternative<?php echo e($errors->has('synonyms') ? ' is-invalid' : ''); ?>" value="<?php echo e($proverb->synonyms); ?>">

                                    <?php if($errors->has('synonyms')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('synonyms')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Save Changes')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('Proverb Details')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Kamusi-Web\resources\views/proverbs/edit.blade.php ENDPATH**/ ?>