<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header', [
        'title' => __('Create a New User'),
        //'description' => __('User profile details'),
        //'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-5 mb-xl-0">
                
            </div>
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('users.store')); ?>" enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>

                            <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <div class="pl-lg-4">
                                <div class="row">
                                    <div class="col-xl-6 order-xl-2 mb-5 mb-xl-0">
                                        <div class="form-group<?php echo e($errors->has('first_name') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-first_name"><?php echo e(__('First Name')); ?></label>
                                            <input type="text" name="first_name" id="input-first_name" class="form-control form-control-alternative<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" value="">

                                            <?php if($errors->has('first_name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 order-xl-2 mb-5 mb-xl-0">
                                        <div class="form-group<?php echo e($errors->has('last_name') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-last_name"><?php echo e(__('Last Name')); ?></label>
                                            <input type="text" name="last_name" id="input-last_name" class="form-control form-control-alternative<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" value="">

                                            <?php if($errors->has('last_name')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>                                    
                                    
                                </div>

                                <div class="row">
                                    <div class="col-xl-6 order-xl-2 mb-5 mb-xl-0">
                                        <div class="form-group<?php echo e($errors->has('dobirth') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-dobirth"><?php echo e(__('Date of Birth')); ?></label>
                                            <input type="text" name="dobirth" id="input-dobirth" class="form-control form-control-alternative<?php echo e($errors->has('dobirth') ? ' is-invalid' : ''); ?>" value="<?php echo e(date('Y-m-d')); ?>">

                                            <?php if($errors->has('dobirth')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('dobirth')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 order-xl-2 mb-5 mb-xl-0">
                                        <div class="form-group<?php echo e($errors->has('gender') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-gender"><?php echo e(__('Gender')); ?></label>
                                            <input type="text" name="gender" id="input-gender" class="form-control form-control-alternative<?php echo e($errors->has('gender') ? ' is-invalid' : ''); ?>" value="">

                                            <?php if($errors->has('gender')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('gender')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>                                    
                                    
                                </div>
                                
                                <div class="row">
                                    <div class="col-xl-6 order-xl-2 mb-5 mb-xl-0">
                                        <div class="form-group<?php echo e($errors->has('town') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-town"><?php echo e(__('Town')); ?></label>
                                            <input type="text" name="town" id="input-town" class="form-control form-control-alternative<?php echo e($errors->has('town') ? ' is-invalid' : ''); ?>">

                                            <?php if($errors->has('town')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('town')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 order-xl-2 mb-5 mb-xl-0">
                                        <div class="form-group<?php echo e($errors->has('country') ? ' has-danger' : ''); ?>">
                                            <label class="form-control-label" for="input-country"><?php echo e(__('Country')); ?></label>
                                            <input type="text" name="country" id="input-country" class="form-control form-control-alternative<?php echo e($errors->has('country') ? ' is-invalid' : ''); ?>" value="KE" required>

                                            <?php if($errors->has('country')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('country')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                  
                                <div class="form-group<?php echo e($errors->has('about') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-about"><?php echo e(__('About')); ?></label>
                                    <input type="text" name="about" id="input-about" class="form-control form-control-alternative<?php echo e($errors->has('about') ? ' is-invalid' : ''); ?>">

                                    <?php if($errors->has('about')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('about')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-email"><?php echo e(__('Email Address')); ?></label>
                                    <input type="email" name="email" id="input-email" class="form-control form-control-alternative<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" value="" required>

                                    <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                    <label class="form-control-label" for="input-current-password"><?php echo e(__('Preferred Password')); ?></label>
                                    <input type="password" name="password" id="input-current-password" class="form-control form-control-alternative<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" required>
                                    
                                    <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="text-center">
                                    <button type="submit" class="btn btn-success mt-4"><?php echo e(__('Register User')); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => __('User Profile')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\kamusi\resources\views/users/create.blade.php ENDPATH**/ ?>