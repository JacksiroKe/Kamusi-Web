<footer class="footer">
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer><?php /**PATH D:\xampp\htdocs\kamusi\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>