<footer class="py-5">
    <div class="container">
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</footer><?php /**PATH D:\xampp\htdocs\Kamusi-Web\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>