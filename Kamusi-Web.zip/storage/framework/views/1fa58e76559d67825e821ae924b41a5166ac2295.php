<div class="header bg-gradient-primary py-7 py-lg-8">
    <div class="container">
        
    </div>
</div><?php /**PATH D:\xampp\htdocs\kamusi\resources\views/layouts/headers/guest.blade.php ENDPATH**/ ?>