<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Http\Requests\ProfileRequest;
use App\Http\Requests\PasswordRequest;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    /**
     * Show the form for editing the profile.
     *
     * @return \Illuminate\View\View
     */
    public function edit()
    {
        return view('profile.edit');
    }

    /**
     * Update the profile
     *
     * @param  \App\Http\Requests\ProfileRequest  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(ProfileRequest $rq)
    {
        DB::beginTransaction();
        try {
            $users = new User;
            $user = $users::find(auth()->user()->id);

            $user->update([
                'name' => $rq->get('name'),
                'title' => $rq->get('title'),
                'bio' => $rq->get('bio'),
                'town' => $rq->get('town'),
                'mobile' => $rq->get('mobile'),
            ]);

            return back()->withStatus(__('Profile successfully updated.'));
        } catch (\Exception $exception) {
            DB::rollBack();
            return redirect()->back()->withError('Error while updating profile');
        }
        DB::commit();
    }

    /**
     * Change the password
     *
     * @param  \App\Http\Requests\PasswordRequest  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function password(PasswordRequest $request)
    {
        auth()->user()->update(['password' => Hash::make($request->get('password'))]);
        return back()->withPasswordStatus(__('Password successfully updated.'));
    }
}
